package com.example.iptvplayer

import android.net.Uri
import org.json.JSONArray
import org.json.JSONObject

/** Minimal Xtream Codes client (live TV only). */
object XtreamClient {

    /** Accepts "host:port", "http://host:port/", or a full player_api.php / get.php URL. */
    fun normalizeServer(input: String): String {
        var s = input.trim()
        if (!s.startsWith("http://", true) && !s.startsWith("https://", true)) s = "http://$s"
        s = s.substringBefore("/player_api.php").substringBefore("/get.php")
        return s.trimEnd('/')
    }

    private fun apiUrl(server: String, user: String, pass: String, action: String? = null): String {
        val base = "$server/player_api.php?username=${Uri.encode(user)}&password=${Uri.encode(pass)}"
        return if (action == null) base else "$base&action=$action"
    }

    private fun JSONObject.str(key: String): String? =
        if (isNull(key)) null else optString(key).takeIf { it.isNotBlank() }

    /**
     * Logs in and returns all live channels.
     * @param ext stream container, "m3u8" (HLS) or "ts"
     */
    fun fetchLiveChannels(server: String, user: String, pass: String, ext: String): List<Channel> {
        // 1) Authenticate
        val auth = JSONObject(download(apiUrl(server, user, pass)))
        val info = auth.optJSONObject("user_info") ?: error("Not an Xtream Codes server")
        if (info.optInt("auth", 0) != 1) error("Login failed - check username and password")
        val status = info.optString("status", "")
        if (status.isNotEmpty() && !status.equals("Active", ignoreCase = true)) {
            error("Account status: $status")
        }

        // 2) Categories (optional - some panels return nothing)
        val categories = HashMap<String, String>()
        try {
            val arr = JSONArray(download(apiUrl(server, user, pass, "get_live_categories")))
            for (i in 0 until arr.length()) {
                val c = arr.getJSONObject(i)
                val id = c.str("category_id") ?: continue
                categories[id] = c.str("category_name") ?: "Other"
            }
        } catch (_: Exception) { }

        // 3) Live streams
        val streams = JSONArray(download(apiUrl(server, user, pass, "get_live_streams")))
        val u = Uri.encode(user)
        val p = Uri.encode(pass)
        val out = ArrayList<Channel>(streams.length())
        for (i in 0 until streams.length()) {
            val s = streams.getJSONObject(i)
            val id = s.str("stream_id") ?: continue
            out += Channel(
                name = s.str("name") ?: "Channel $id",
                url = "$server/live/$u/$p/$id.$ext",
                logo = s.str("stream_icon"),
                group = categories[s.str("category_id")] ?: "Other"
            )
        }
        return out
    }
}
