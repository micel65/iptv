package com.example.iptvplayer

/** Parses extended M3U / M3U8 playlists (#EXTINF entries). */
object M3uParser {
    private val attrRegex = Regex("""([\w-]+)="([^"]*)"""")

    fun parse(text: String): List<Channel> {
        val result = mutableListOf<Channel>()
        var name: String? = null
        var logo: String? = null
        var group = "Other"

        for (raw in text.lineSequence()) {
            val line = raw.trim()
            when {
                line.startsWith("#EXTINF", ignoreCase = true) -> {
                    val attrs = attrRegex.findAll(line).associate {
                        it.groupValues[1].lowercase() to it.groupValues[2]
                    }
                    logo = attrs["tvg-logo"]?.takeIf { it.isNotBlank() }
                    group = attrs["group-title"]?.takeIf { it.isNotBlank() } ?: "Other"
                    name = line.substringAfterLast(",").trim()
                        .ifEmpty { attrs["tvg-name"] ?: "Unknown" }
                }
                line.isNotEmpty() && !line.startsWith("#") -> {
                    val n = name
                    if (n != null) result += Channel(n, line, logo, group)
                    name = null; logo = null; group = "Other"
                }
            }
        }
        return result
    }
}
