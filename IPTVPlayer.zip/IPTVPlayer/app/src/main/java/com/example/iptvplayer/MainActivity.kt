package com.example.iptvplayer

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import coil.compose.AsyncImage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                Surface(Modifier.fillMaxSize()) { IptvApp() }
            }
        }
    }
}

@Composable
fun IptvApp() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val prefs = remember { context.getSharedPreferences("iptv", Context.MODE_PRIVATE) }

    // Source settings (0 = Xtream Codes, 1 = M3U)
    var mode by remember { mutableIntStateOf(prefs.getInt("mode", 0)) }
    var server by remember { mutableStateOf(prefs.getString("server", "") ?: "") }
    var username by remember { mutableStateOf(prefs.getString("user", "") ?: "") }
    var password by remember { mutableStateOf(prefs.getString("pass", "") ?: "") }
    var ext by remember { mutableStateOf(prefs.getString("ext", "m3u8") ?: "m3u8") }
    var m3uUrl by remember { mutableStateOf(prefs.getString("url", "") ?: "") }
    var showSettings by remember { mutableStateOf(true) }

    var channels by remember { mutableStateOf(emptyList<Channel>()) }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var query by remember { mutableStateOf("") }
    var group by remember { mutableStateOf<String?>(null) }
    var current by remember { mutableStateOf<Channel?>(null) }

    // ---- Player ----
    val player = remember { ExoPlayer.Builder(context).build() }
    DisposableEffect(player) {
        val listener = object : Player.Listener {
            override fun onPlayerError(e: PlaybackException) {
                error = "Playback error: ${e.errorCodeName}" +
                    if (current?.url?.contains("/live/") == true)
                        " (try switching the stream format between m3u8 and ts)" else ""
            }
        }
        player.addListener(listener)
        onDispose {
            player.removeListener(listener)
            player.release()
        }
    }
    LaunchedEffect(current) {
        current?.let {
            error = null
            player.setMediaItem(MediaItem.fromUri(it.url))
            player.prepare()
            player.playWhenReady = true
        }
    }

    // ---- Loading ----
    fun load(source: () -> List<Channel>) {
        scope.launch {
            loading = true; error = null
            try {
                val list = withContext(Dispatchers.IO) { source() }
                if (list.isEmpty()) error = "No channels found."
                channels = list
                group = null; query = ""
                if (list.isNotEmpty()) showSettings = false
            } catch (e: Exception) {
                error = "Could not load: ${e.message}"
            } finally {
                loading = false
            }
        }
    }

    fun loadXtream() {
        if (server.isBlank() || username.isBlank() || password.isBlank()) {
            error = "Enter server, username and password."; return
        }
        val srv = XtreamClient.normalizeServer(server)
        server = srv
        prefs.edit().putInt("mode", 0).putString("server", srv).putString("user", username)
            .putString("pass", password).putString("ext", ext).apply()
        load { XtreamClient.fetchLiveChannels(srv, username.trim(), password, ext) }
    }

    fun loadM3u() {
        val u = m3uUrl.trim()
        if (u.isEmpty()) return
        prefs.edit().putInt("mode", 1).putString("url", u).apply()
        load { M3uParser.parse(download(u)) }
    }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri?.let {
            load {
                val text = context.contentResolver.openInputStream(it)!!
                    .bufferedReader().use { r -> r.readText() }
                M3uParser.parse(text)
            }
        }
    }

    // Auto-load the last used source
    LaunchedEffect(Unit) {
        if (mode == 0 && server.isNotBlank() && username.isNotBlank()) loadXtream()
        else if (mode == 1 && m3uUrl.isNotBlank()) loadM3u()
    }

    val groups = remember(channels) { channels.map { it.group }.distinct().sorted() }
    val filtered = remember(channels, query, group) {
        channels.filter {
            (group == null || it.group == group) &&
                (query.isBlank() || it.name.contains(query, ignoreCase = true))
        }
    }

    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        // Player
        current?.let { ch ->
            AndroidView(
                modifier = Modifier.fillMaxWidth().aspectRatio(16f / 9f),
                factory = { ctx -> PlayerView(ctx).apply { this.player = player } }
            )
            Text(
                ch.name,
                style = MaterialTheme.typography.titleMedium,
                modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
            )
        }

        // Source settings (collapsible once channels are loaded)
        if (showSettings || channels.isEmpty()) {
            TabRow(selectedTabIndex = mode) {
                Tab(selected = mode == 0, onClick = { mode = 0 }, text = { Text("Xtream Codes") })
                Tab(selected = mode == 1, onClick = { mode = 1 }, text = { Text("M3U") })
            }
            Column(
                Modifier.padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                if (mode == 0) {
                    OutlinedTextField(
                        value = server, onValueChange = { server = it },
                        label = { Text("Server (e.g. http://host:8080)") },
                        singleLine = true, modifier = Modifier.fillMaxWidth()
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = username, onValueChange = { username = it },
                            label = { Text("Username") },
                            singleLine = true, modifier = Modifier.weight(1f)
                        )
                        OutlinedTextField(
                            value = password, onValueChange = { password = it },
                            label = { Text("Password") },
                            singleLine = true,
                            visualTransformation = PasswordVisualTransformation(),
                            modifier = Modifier.weight(1f)
                        )
                    }
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text("Format:")
                        FilterChip(selected = ext == "m3u8", onClick = { ext = "m3u8" },
                            label = { Text("m3u8 (HLS)") })
                        FilterChip(selected = ext == "ts", onClick = { ext = "ts" },
                            label = { Text("ts") })
                        Spacer(Modifier.weight(1f))
                        Button(onClick = { loadXtream() }, enabled = !loading) { Text("Login") }
                    }
                } else {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedTextField(
                            value = m3uUrl, onValueChange = { m3uUrl = it },
                            label = { Text("M3U playlist URL") },
                            singleLine = true, modifier = Modifier.weight(1f)
                        )
                        Button(onClick = { loadM3u() }, enabled = !loading) { Text("Load") }
                    }
                    TextButton(onClick = { picker.launch(arrayOf("*/*")) }) {
                        Text("Open local M3U file")
                    }
                }
            }
        } else {
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("${channels.size} channels", style = MaterialTheme.typography.bodySmall)
                Spacer(Modifier.weight(1f))
                TextButton(onClick = { showSettings = true }) { Text("Change source") }
            }
        }

        error?.let {
            Text(
                it,
                color = MaterialTheme.colorScheme.error,
                modifier = Modifier.padding(horizontal = 12.dp)
            )
        }
        if (loading) LinearProgressIndicator(Modifier.fillMaxWidth())

        if (channels.isNotEmpty()) {
            OutlinedTextField(
                value = query, onValueChange = { query = it },
                label = { Text("Search channels") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp)
            )
            LazyRow(
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                item {
                    FilterChip(selected = group == null, onClick = { group = null },
                        label = { Text("All") })
                }
                items(groups) { g ->
                    FilterChip(selected = group == g, onClick = { group = g },
                        label = { Text(g) })
                }
            }
        }

        // Channel list
        LazyColumn(Modifier.weight(1f)) {
            items(filtered) { ch ->
                Row(
                    Modifier.fillMaxWidth()
                        .clickable { current = ch }
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    AsyncImage(
                        model = ch.logo,
                        contentDescription = null,
                        modifier = Modifier.size(44.dp)
                    )
                    Spacer(Modifier.width(12.dp))
                    Column {
                        Text(ch.name, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(
                            ch.group,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
                HorizontalDivider()
            }
        }
    }
}
