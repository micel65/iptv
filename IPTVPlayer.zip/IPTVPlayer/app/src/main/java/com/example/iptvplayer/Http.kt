package com.example.iptvplayer

import java.net.HttpURLConnection
import java.net.URL

/** Blocking HTTP GET returning the body as text. Call from Dispatchers.IO. */
fun download(url: String): String {
    val conn = URL(url).openConnection() as HttpURLConnection
    conn.connectTimeout = 15_000
    conn.readTimeout = 60_000
    conn.instanceFollowRedirects = true
    conn.setRequestProperty("User-Agent", "Mozilla/5.0 (Android) IPTVPlayer/1.0")
    return try {
        if (conn.responseCode !in 200..299) error("Server returned HTTP ${conn.responseCode}")
        conn.inputStream.bufferedReader().use { it.readText() }
    } finally {
        conn.disconnect()
    }
}
