# IPTV Player (Android)

A simple IPTV player built with Kotlin, Jetpack Compose and Media3 (ExoPlayer).

## Open & run
1. Open this folder in Android Studio (Koala or newer). It will generate the Gradle wrapper and sync.
2. Run on a device/emulator (Android 7.0+).
3. Xtream Codes tab: enter server (e.g. http://host:8080), username, password, pick m3u8 or ts, tap Login.
   M3U tab: paste a playlist URL and tap Load, or choose a local .m3u file.

## Features
- Xtream Codes login (live TV: categories + channels via player_api.php)
- M3U / M3U8 parsing (name, logo, group)
- Search + group filter
- HLS, DASH-less progressive and MPEG-TS playback via ExoPlayer
- Remembers the last playlist URL

## Ideas to extend
- Favorites (Room/DataStore), EPG (XMLTV), Picture-in-Picture,
  Android TV UI, fullscreen toggle, VOD/series, encrypted credential storage, 
Note: this app ships with no channels. Use only playlists you have the right to access.
